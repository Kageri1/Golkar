import { Component } from '@angular/core';


@Component({
	selector: 'ngbd-dropdown-basic',
	templateUrl: './dropdown-collapse.component.html'
})
 
export class NgbdDropdownBasic{
  // This is for the collapse example
  public isCollapsed = false;
}
